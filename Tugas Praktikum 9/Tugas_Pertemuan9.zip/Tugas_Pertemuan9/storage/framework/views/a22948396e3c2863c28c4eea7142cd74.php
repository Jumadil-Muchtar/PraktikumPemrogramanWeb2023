<!-- Tombol untuk menghapus data -->
<h2>Delete</h2>
<form method="post" action="<?php echo e(route ('delete')); ?>">
    <?php echo csrf_field(); ?>
    <input type="number" name="id" placeholder="ID Produk">
    <!-- <?php echo method_field('DELETE'); ?> -->
    <button type="submit">Hapus</button>
    <?php if(session('success')): ?>
        <p>
            <?php echo e(session('success')); ?>

        <p>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <p>
            <?php echo e(session('error')); ?>

        <p>
    <?php endif; ?>
</form><?php /**PATH C:\Users\caca\Documents\Ean\prakweb\PraktikumPemrogramanWeb2023\Tugas Praktikum 9\Tugas_Pertemuan9\resources\views/delete.blade.php ENDPATH**/ ?>