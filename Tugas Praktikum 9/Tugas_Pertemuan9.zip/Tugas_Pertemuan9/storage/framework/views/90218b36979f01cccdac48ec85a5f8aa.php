<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create</title>
</head>
<body>
    <h2>Insert Data</h2>
    <form action="<?php echo e(route('create')); ?>" method="post">
         <!-- CSRF (Cross-Site Request Forgery)untuk melindungi aplikasi Anda dari serangan CSRF yang 
         dapat dieksploitasi oleh penyerang. -->
         <?php echo csrf_field(); ?>
         <input type="text" name="nama" placeholder="Nama Produk">
        <input type="text" name="merk" placeholder="Merk Produk">
        <input type="number" name="storage" placeholder="Storage Produk">
        <input type="number" name="ram" placeholder="Ram Produk">
        <input type="number" name="harga" placeholder="Harga Produk">
        <button type="submit">Insert Produk</button>
        <?php if(session('success')): ?>
            <p>
                <?php echo e(session('success')); ?>

            <p>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <p>
                <?php echo e(session('error')); ?>

            <p>
        <?php endif; ?>
        

    </form>
</body>
</html>
<?php /**PATH C:\Users\caca\Documents\Ean\prakweb\PraktikumPemrogramanWeb2023\Tugas Praktikum 9\Tugas_Pertemuan9\resources\views/create.blade.php ENDPATH**/ ?>