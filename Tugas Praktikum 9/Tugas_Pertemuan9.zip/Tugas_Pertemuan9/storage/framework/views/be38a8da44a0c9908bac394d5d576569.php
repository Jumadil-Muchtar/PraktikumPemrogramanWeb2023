<h2>Update</h2>
<form method="POST" action=""> 
    <?php echo csrf_field(); ?>
    <!-- <?php echo method_field('PUT'); ?> -->
    <input type="number" name="id" placeholder="ID Produk">
    <input type="text" name="nama" placeholder="Nama Produk">
    <input type="text" name="merk" placeholder="Merk Produk">
    <input type="number" name="storage" placeholder="Storage Produk">
    <input type="number" name="ram" placeholder="Ram Produk">
    <input type="number" name="harga" placeholder="Harga Produk">

    <!-- Tambahkan field lain sesuai kebutuhan -->

    <button type="submit">Update</button>
</form>

<!-- Tombol untuk menghapus data -->
<h2>Delete</h2>
<form method="POST" action="<?php echo e(route ('delete')); ?>">
    <?php echo csrf_field(); ?>
    <input type="number" name="id" placeholder="ID Produk">
    <!-- <?php echo method_field('DELETE'); ?> -->
    <button type="submit">Hapus</button>
</form>



<?php /**PATH C:\Users\caca\Documents\Ean\prakweb\PraktikumPemrogramanWeb2023\Tugas Praktikum 9\Tugas_Pertemuan9\resources\views/editdelete.blade.php ENDPATH**/ ?>