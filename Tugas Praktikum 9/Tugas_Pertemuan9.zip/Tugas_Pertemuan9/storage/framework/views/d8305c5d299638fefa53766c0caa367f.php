<!DOCTYPE html>
<html>
<head>
    <title>Index</title>
</head>
<body>
    <h1>Daftar Produk Hape</h1>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p>============================================</p>
    <p>Id Produk : <?php echo e($produk->id); ?></p>
    <p>Nama Produk : <a href="<?php echo e(route('details', ['details' => $produk->id])); ?>"><?php echo e($produk->nama); ?></a></p>
        <!-- <p>Nama Produk : <?php echo e($produk->nama); ?></p> -->
        <!-- <p>Merk Produk : <?php echo e($produk->merk); ?></p>
        <p>Storage : <?php echo e($produk->storage); ?> GB</p>
        <p>Ram : <?php echo e($produk->ram); ?> GB</p>
        <p>Harga : Rp.<?php echo e($produk->harga); ?></p> -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\Users\caca\Documents\Ean\prakweb\PraktikumPemrogramanWeb2023\Tugas Praktikum 9\Tugas_Pertemuan9\resources\views/index.blade.php ENDPATH**/ ?>