<!DOCTYPE html>
<html>
<head>
    <title>Details</title>
</head>
<body>
    <h1>Detail Produk</h1>
    <?php if($product): ?>
        <p>============================================</p>
        <p>Id Produk : <?php echo e($product->id); ?></p>
        <p>Nama Produk : <?php echo e($product->nama); ?></p>
        <p>Merk Produk : <?php echo e($product->merk); ?></p>
        <p>Storage : <?php echo e($product->storage); ?> GB</p>
        <p>Ram : <?php echo e($product->ram); ?> GB</p>
        <p>Harga : Rp.<?php echo e($product->harga); ?></p>
    <?php else: ?>
        <p>Produk tidak ditemukan.</p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\caca\Documents\Ean\prakweb\PraktikumPemrogramanWeb2023\Tugas Praktikum 9\Tugas_Pertemuan9\resources\views/details.blade.php ENDPATH**/ ?>