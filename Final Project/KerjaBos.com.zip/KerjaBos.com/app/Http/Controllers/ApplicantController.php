<?php

namespace App\Http\Controllers;

use App\Models\Apply;
use Illuminate\Support\Facades\Auth;

class ApplicantController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Jika rolenya adalah admin, tampilkan semua aplikasi
        if ($user->role == 'admin') {
            $applicants = Apply::all();
        }
        // Jika rolenya adalah company, tampilkan hanya aplikasi yang sesuai dengan post yang dibuat oleh user yang sedang login
        elseif ($user->role == 'company') {
            $applicants = Apply::with('post')
                ->whereHas('post', function ($query) use ($user) {
                    $query->where('user_id', $user->id);
                })
                ->get();
        }

        return view('backend.applicantManagement.index', compact('applicants'));
    }

    public function destroy($id)
    {
        // Dapatkan path CV sebelum menghapus aplikasi
        $apply = Apply::findOrFail($id);

        // Hapus aplikasi dari database
        $apply->delete();

        return redirect()->route('dashboard.applicant-management.index')->with('success', 'Applicant deleted successfully');
    }

    public function apply($jobId)
    {
        // Logika untuk meng-handle apply
        return redirect()->route('dashboard.applicant-management.index')->with('success', 'Applied successfully');
    }
}
