<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Support\Facades\Route;
use Illuminate\View\View;

class JobPostController extends Controller
{
    public function index(): View
    {

        $posts = Post::where('active', true)->paginate(6); // Adjust the pagination size as needed

        if (Route::currentRouteName() === 'dashboard.jobs') {
            $allJobsPosts = $posts;
            return view('allJobs', compact('allJobsPosts'));
        }
        return view('homepage', compact('posts'));
    }

    public function show($slug)
    {
        $post = Post::where('slug', $slug)->firstOrFail();

        return view('detailJob', compact('post'));
    }

}
