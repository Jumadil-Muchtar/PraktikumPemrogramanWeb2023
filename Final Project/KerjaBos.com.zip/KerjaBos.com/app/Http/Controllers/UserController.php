<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function index()
    {
        $users = User::orderBy('role', 'asc')->get();
        return view('backend.usermanagement.index', compact('users'));
    }

    public function create()
    {
        return view('backend.usermanagement.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'username' => 'required|unique:users',
            'email' => 'required|email|unique:users',
            'role' => 'required',
            'password' => 'required|min:8|confirmed',
            'logo' => 'image|mimes:jpeg,png,jpg,gif|max:2048', // Sesuaikan dengan kebutuhan Anda
        ]);

        $data = $request->except(['password']);

        // Hash password sebelum menyimpan ke database
        $data['password'] = Hash::make($request->password);

        // Simpan data ke database
        $user = User::create($data);

        // Simpan logo ke penyimpanan dan update kolom 'logo' pada model User
        if ($request->hasFile('logo')) {
            $logoPath = $request->file('logo')->store('logos', 'public');
            $user->update(['logo' => $logoPath]);
        }

        return redirect()->route('dashboard.usermanagement.index')->with('success', 'User created successfully.');
    }

    public function edit(User $user)
    {
        return view('backend.usermanagement.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        // Validasi input form
        $rules = [
            'name' => 'required',
            'username' => 'required|unique:users,username,' . $user->id,
            'email' => 'required|email|unique:users,email,' . $user->id,
            'role' => 'required|in:user,company,admin',
        ];

        // Jika role bukan company, tambahkan validasi age dan gender
        if ($request->role !== 'company' || $request->role !== 'admin') {
            $rules['age'] = 'required';
            $rules['gender'] = 'required|in:female,male';
        }

        $request->validate($rules);

        // Update data di dalam database
        $data = $request->all();

        $user->update($data);

        return redirect()->route('dashboard.usermanagement.index')->with('success', 'User updated successfully.');
    }

    public function destroy(User $user)
    {
        // Hapus data dari database
        $user->delete();

        return redirect()->route('dashboard.usermanagement.index')->with('success', 'User deleted successfully.');
    }
}
