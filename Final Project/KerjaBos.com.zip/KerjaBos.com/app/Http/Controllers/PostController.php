<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PostController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        // Jika rolenya adalah admin, tampilkan semua postingan
        if ($user->role == 'admin') {
            $posts = Post::orderBy('created_at', 'desc')->get();
        }
        // Jika rolenya adalah company, tampilkan hanya postingan yang dibuat oleh company tersebut
        elseif ($user->role == 'company') {
            $posts = Post::where('user_id', $user->id)->orderBy('created_at', 'desc')->get();
        }
        // Tambahan logika dapat ditambahkan untuk role lainnya jika diperlukan

        return view('backend.job-management.index', compact('posts'));
    }

    public function create()
    {
        return view('backend.job-management.create');
    }

    public function store(Request $request)
    {
        // Validasi request
        $request->validate([
            'title' => 'required|string',
            'location' => 'required|string',
            'type' => 'required|in:Full Time,Part Time,Freelance,Negotiable',
            'phone' => 'required|string|max:12',
            'description' => 'required|string',
            'salary' => 'required|string',
        ]);

        // Mendapatkan pengguna yang terotentikasi
        $user = auth()->user();

        // Memeriksa apakah pengguna terotentikasi
        if (!$user) {
            return redirect()->route('login')->with('error', 'You must be logged in to create a post.');
        }

        // Menghasilkan slug dari judul
        $slug = Str::slug($request->title);

        // Simpan data ke database dengan menetapkan user_id dan slug
        $post = new Post($request->all());
        $post->user_id = $user->id;
        $post->slug = $slug;

        // Set nilai default 'active' menjadi true
        $post->active = true;

        $post->save();

        return redirect()->route('dashboard.job-management')->with('success', 'Success Created Post');
    }

    public function edit(Post $post)
    {
        return view('backend.job-management.edit', compact('post'));
    }

    // Pada method update
    public function update(Request $request, Post $post)
    {
        // Validasi request
        $request->validate([
            'title' => 'required',
            'type' => 'required|in:Full Time,Part Time,Freelance,Negotiable',
            'phone' => 'required|string|max:15',
            'description' => 'required',
            'salary' => 'required',
            'active' => 'required|boolean',
        ]);

        // Update data di database
        $post->update($request->all());

        return redirect()->route('dashboard.job-management')->with('success', 'Success Updated Post');
    }

    public function destroy(Post $post)
    {
        // Hapus data dari database
        $post->delete();

        return redirect()->route('dashboard.job-management')->with('success', 'Success Deleted Post');
    }
}
