<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;

class SearchResultController extends Controller
{
    public function index(Request $request)
    {
        // Check if the request has a 'search' parameter
        if ($request->has('search')) {
            $searchTerm = $request->input('search');

            // Use paginate() instead of get() to enable pagination
            $posts = Post::where('active', true)
                ->where(function ($query) use ($searchTerm) {
                    $query->where('title', 'like', '%' . $searchTerm . '%')
                        ->orWhere('type', 'like', '%' . $searchTerm . '%')
                        ->orWhere('salary', 'like', '%' . $searchTerm . '%')
                        ->orWhere('location', 'like', '%' . $searchTerm . '%')
                        ->orWhereHas('user', function ($query) use ($searchTerm) {
                            $query->where('name', 'like', '%' . $searchTerm . '%');
                        });
                })
                ->paginate(10); // Change the pagination size as needed

            return view('resultpages', compact('posts'));
        }

        // If no search parameter, redirect to the home page or any other default page
        return redirect('/dashboard/jobs');
    }
}
