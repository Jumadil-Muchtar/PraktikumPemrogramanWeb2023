<?php

namespace App\Http\Controllers;

use App\Models\Post;

class DashboardController extends Controller
{
    public function dashboard()
    {
        $user = auth()->user();

        // Check if the user is admin or company
        if ($user->role == 'admin' || $user->role == 'company') {
            // Retrieve all posts without pagination
            $posts = Post::all();
        } else {
            // Retrieve paginated active posts
            $posts = Post::where('active', true)->paginate(6);
        }

        return view('dashboard', compact('posts'));
    }
}
