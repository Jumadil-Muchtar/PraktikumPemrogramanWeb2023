<?php

namespace App\Http\Controllers;

use App\Models\Apply;
use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ApplyController extends Controller
{
    public function applyPost(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'post_id' => 'required|exists:posts,id',
            'message' => 'required|string',
        ]);

        // Cek apakah post dengan ID yang diberikan ada
        $post = Post::find($request->input('post_id'));

        if (!$post) {
            return redirect()->back()->with('error', 'Invalid Post ID');
        }

        // Cek apakah user memiliki role 'user'
        $userRole = Auth::user()->role;

        if ($userRole !== 'user') {
            return redirect()->back()->with('error', 'You are not allowed to apply for jobs.');
        }

        // Cek apakah user sudah mengirimkan aplikasi untuk postingan ini sebelumnya
        $existingApplication = Apply::where('user_id', auth()->id())
            ->where('post_id', $post->id)
            ->first();

        if ($existingApplication) {
            return redirect()->back()->with('error', 'You have already applied for this job.');
        }

        $applyData = [
            'user_id' => auth()->id(),
            'post_id' => $post->id,
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'skills' => $request->input('skills'),
            'message' => $request->input('message'),
        ];

        Apply::create($applyData);

        return redirect()->back()->with('success', 'Application submitted successfully!');
    }

    public function index()
    {
        // Mendapatkan user yang sedang login
        $user = Auth::user();

        // Mengambil data applies berdasarkan user yang login
        $applies = $user->applies;

        // Kirim data ke view
        return view('applied', ['applies' => $applies]);
    }

}
