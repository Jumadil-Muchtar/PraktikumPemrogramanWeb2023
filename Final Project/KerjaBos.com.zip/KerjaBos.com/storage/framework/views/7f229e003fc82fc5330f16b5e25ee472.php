<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg"
                style="height: 100%; padding: 10%;background-color:bisque">
                <div class="text-gray-900 mx-auto"
                    style="text-align: center; font-weight: bolder; font-size: 55px; padding-left: 10%; padding-right: 10%">
                    <h1>KerjaBos.com</h1>
                </div>
                <div class="text-gray-900 mt-3"
                    style="text-align: justify; font-size: 17px; padding-left: 19%; padding-right: 19%">
                    <p>
                        Platform pencarian pekerjaan yang didedikasikan untuk membantu para pencari kerja menemukan
                        peluang karir terbaik. Dengan fokus pada pengalaman pengguna yang intuitif dan berbagai fitur
                        unggulan, KerjaBos.com menjadi mitra ideal bagi mereka yang ingin mencapai karir yang sukses.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg" style="height: 100%;background-color:bisque">
                <div class="container-fluid p-5" style="width: 60%">
                    <form class="d-flex" role="search">
                        <input class="form-control me-2 rounded-md" type="search" placeholder="Search"
                            aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Sites\KerjaBos.com\resources\views/welcome.blade.php ENDPATH**/ ?>