<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg" style="height: 100%; background-color: bisque;">

                <?php if(empty($post)): ?>
                    <div class="row d-flex">
                        <div class="col-md-4 text-center p-5 mx-auto">
                            <p>No results found.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="row d-flex" data-aos="zoom-out-up">
                        <div class="col-md-10 py-3 ms-4 mt-2">
                            <h1 class="text-uppercase fw-bold" style="font-size: 20px">
                                <?php echo e($post->title); ?>

                            </h1>
                            <div class="d-flex align-items-center mt-2">
                                <div class="me-3">
                                    <img src="<?php echo e(asset($post->user->logo)); ?>" alt="Photo"
                                        style="max-width: 50px; border-radius: 50%;">
                                </div>
                                <h1 class="font-bold text-dark text-uppercase d-flex" style="font-size: 15px; gap: 5px">
                                    <?php echo e($post->user->name); ?>

                                    <img src="/img/verified.png" alt="">
                                </h1>
                            </div>

                            <div class="p-2 mt-4">
                                <p>
                                    <?php echo $post->description; ?>

                                </p>
                            </div>

                            
                            <button class="btn btn-primary mt-4" data-toggle="modal"
                                data-target="#applyModal">Apply</button>
                        </div>
                    </div>
                    <div class="mt-2">
                        <!-- Modal -->
                        <div class="modal fade" id="applyModal" tabindex="-1" role="dialog"
                            aria-labelledby="applyModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="applyModalLabel">Apply Form</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body bg-dark text-white">
                                        <!-- Formulir yang akan muncul di dalam modal -->
                                        <form action="<?php echo e(route('apply.post')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>

                                            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">

                                            <input type="hidden" name="user_role" value="<?php echo e(auth()->user()->role); ?>">

                                            <div class="mb-3">
                                                <label for="name" class="form-label">Name</label>
                                                <input type="text" value="<?php echo e(auth()->user()->name); ?>" id="name"
                                                    name="name" class="form-control rounded-md" required>
                                            </div>

                                            <div class="mb-3">
                                                <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'skills','value' => __('Skills')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'skills','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Skills'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                                                <div class="bg-white rounded-md p-2 text-dark">
                                                    <input id="skills" type="hidden" name="skills"
                                                        value="<?php echo e(auth()->user()->skills); ?>">
                                                    <textarea id="editor-skills" name="skills" rows="5" style="resize: vertical; width: 100%; min-height: 100px;"><?php echo e(auth()->user()->skills); ?></textarea>
                                                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('skills')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('skills'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <label for="email" class="form-label">Email</label>
                                                <input type="email" value="<?php echo e(auth()->user()->email); ?>" id="email"
                                                    name="email" class="form-control rounded-md" required>
                                            </div>


                                            <div class="mb-3">
                                                <label for="message" class="form-label">Message</label>
                                                <textarea id="message" name="message" class="form-control rounded-md" required></textarea>
                                            </div>

                                            <div class="mb-3 mt-2">
                                                <button type="submit"
                                                    class="btn btn-success text-light">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                <?php endif; ?>

            </div>
        </div>
    </div>

    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo e(session('success')); ?>',
            });
        </script>
    <?php elseif(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo e(session('error')); ?>',
            });
        </script>
    <?php endif; ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Sites\KerjaBos.com\resources\views/detailJob.blade.php ENDPATH**/ ?>