<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['id', 'name', 'label']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['id', 'name', 'label']); ?>
<?php foreach (array_filter((['id', 'name', 'label']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes); ?>>
    <label for="<?php echo e($id); ?>" class="block text-sm font-medium text-light"><?php echo e($label); ?></label>
    <input type="password" name="<?php echo e($name); ?>" id="<?php echo e($id); ?>" autocomplete="new-password"
        <?php echo e($attributes->merge(['class' => 'mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 bg-transparent'])); ?>>
</div>
<?php /**PATH D:\Sites\KerjaBos.com\resources\views/components/password-input.blade.php ENDPATH**/ ?>