<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg"
                style="height: 100%; padding: 10%; background-color:bisque">
                <div class="text-gray-900 mx-auto"
                    style="text-align: center; font-weight: bolder; font-size: 55px; padding-left: 10%; padding-right: 10%"
                    data-aos="zoom-out-up">

                    <h1
                        style="background-clip: text; color: transparent; background-image: linear-gradient(to right, #FFE4C4, #111827);">
                        KerjaBos.com</h1>
                </div>
                <div class="text-gray-900 mt-3"
                    style="text-align: justify; font-size: 17px; padding-left: 19%; padding-right: 19%"
                    data-aos="zoom-out-up">
                    <p>
                        Platform pencarian pekerjaan yang didedikasikan untuk membantu para pencari kerja menemukan
                        peluang karir terbaik. Dengan fokus pada pengalaman pengguna yang intuitif dan berbagai fitur
                        unggulan, KerjaBos.com menjadi mitra ideal bagi mereka yang ingin mencapai karir yang sukses.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg" style="height: 100%; background-color:bisque">
                <div class="row d-flex">
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-4 pb-5 pt-5">
                            <a href="<?php echo e(route('job.detail', $post->slug)); ?>">
                                <div class="card mx-auto" style="width: 18rem;" data-aos="zoom-out-up">
                                    <div class="card-body bg-body-tertiary rounded-lg">
                                        <h5 class="card-title" style="font-weight: 800">
                                            <?php echo e(Str::limit($post->title, $limit = 30, $end = '...')); ?>

                                        </h5>
                                        <h6 class="card-subtitle mb-2 text-body-secondary d-flex gap-1"
                                            style="font-size: 13px">
                                            <?php echo e(optional($post->user)->name); ?>

                                            <img src="/img/verified.png" alt="">
                                        </h6>
                                        <hr class="p-1">
                                        <div class="d-flex gap-3 mb-2">
                                            <img src="/img/briefcase.png" alt="">
                                            <p class="card-text mt-1" style="font-size: 13px">
                                                <?php echo e($post->type); ?>

                                            </p>
                                        </div>
                                        <div class="d-flex gap-3 mb-2">
                                            <img src="/img/location.png" alt="">
                                            <p class="card-text mt-1" style="font-size: 13px"><?php echo e($post->location); ?></p>
                                        </div>
                                        <div class="d-flex gap-3 mb-2">
                                            <img src="/img/salary.png" alt="">
                                            <p class="card-text mt-1" style="font-size: 13px"><?php echo e($post->salary); ?></p>
                                        </div>
                                        <a href="<?php echo e(route('job.detail', $post->slug)); ?>"
                                            class="badge bg-warning px-3 py-2">
                                            Details
                                        </a>
                                    </div>
                                </div>
                            </a>

                        </div>
                        <?php if($loop->iteration % 3 == 0): ?>
                </div>
                <div class="row d-flex">
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-md-12 text-center py-5">
                        <p>No results found.</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="mt-4">
                <div class="d-flex justify-content-center">
                    <?php echo e($posts->links('vendor.pagination.simple')); ?>

                </div>
            </div>
        </div>
    </div>
    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '<?php echo e(session('success')); ?>',
            });
        </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Sites\KerjaBos.com\resources\views/homepage.blade.php ENDPATH**/ ?>