<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\Apply;
use App\Models\Post;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();
        Apply::factory(20)->create();
        Post::factory(30)->create();

        // ADMIN
        User::factory()->create([
            'name' => 'Admin',
            'username' => 'admin',
            'email' => 'admin@gmail.com',
            'phone' => '082292367613',
            'role' => 'admin',
            'password' => 'admin',
        ]);

        // USER BIASA
        User::factory()->create([
            'name' => 'Mahendra Kirana M.B',
            'username' => 'mahendra21',
            'email' => 'mahendra@gmail.com',
            'phone' => '082292367613',
            'role' => 'user',
            'password' => 'user',
        ]);

        User::factory()->create([
            'name' => 'Muh.Ardiansyah Asrifah',
            'username' => 'ardi21',
            'email' => 'ardi@gmail.com',
            'phone' => '082255224377',
            'role' => 'user',
            'password' => 'user',
        ]);

        User::factory()->create([
            'name' => 'Andi Alisha Faiqihah',
            'username' => 'alisha21',
            'email' => 'alisha@gmail.com',
            'phone' => '082293222361',
            'role' => 'user',
            'password' => 'user',
        ]);

        // COMPANY
        User::factory()->create([
            'name' => 'PT.SISFO 22',
            'username' => 'sisfo22',
            'email' => 'sisfo22@gmail.com',
            'phone' => '082222222222',
            'logo' => 'img/laravel.png',
            'role' => 'company',
            'password' => 'company',
        ]);

        User::factory()->create([
            'name' => 'PT.SISFO 21',
            'username' => 'sisfo21',
            'email' => 'sisfo21@gmail.com',
            'phone' => '082121212121',
            'logo' => 'img/laravel.png',
            'role' => 'company',
            'password' => 'company',
        ]);

        User::factory()->create([
            'name' => 'PT.SISFO 23',
            'username' => 'sisfo23',
            'email' => 'sisfo23@gmail.com',
            'phone' => '082323232323',
            'logo' => 'img/laravel.png',
            'role' => 'company',
            'password' => 'company',
        ]);
    }
}
