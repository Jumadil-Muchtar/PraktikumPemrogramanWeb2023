<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class PostFactory extends Factory
{
    public function definition(): array
    {
        $title = $this->faker->sentence;

        return [
            'title' => $title,
            'slug' => Str::slug($title), // Generate slug from the title
            'location' => $this->faker->city,
            'type' => $this->faker->randomElement(['Full Time', 'Part Time', 'Freelance', 'Negotiable']),
            'phone' => $this->faker->numerify('+1##########'),
            'user_id' => $this->faker->numberBetween(5, 7),
            'description' => $this->faker->paragraph,
            'salary' => $this->faker->numberBetween(30000, 100000),
            'active' => $this->faker->boolean, // Randomly set to true or false
            'created_at' => $this->faker->dateTimeBetween('-1 year', 'now'),
            'updated_at' => now(),
        ];
    }
}
