<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ApplyController;
use App\Http\Controllers\JobPostController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ApplicantController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\SearchResultController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
 */

/** */

Route::middleware('guest')->group(function () {
    Route::get('/', [JobPostController::class, 'index'])->name('home');

});

Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'dashboard'])->name('dashboard');
    Route::get('/dashboard/jobs/{slug}', [JobPostController::class, 'show'])->name('job.detail');
    Route::get('/dashboard/jobs', [JobPostController::class, 'index'])->name('dashboard.jobs');
    Route::get('/search-results', [SearchResultController::class, 'index'])->name('search.results');
    Route::get('/applications', [ApplyController::class, 'index'])->name('applications.index');
    Route::post('/apply', [ApplyController::class, 'applyPost'])->name('apply.post');

    Route::middleware('auth')->group(function () {
        Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
        Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
        Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    });
    
    Route::middleware('role:admin')->group(function () {
        // Admin-specific routes
        Route::get('/dashboard/usermanagement', [UserController::class, 'index'])->name('dashboard.usermanagement.index');
        Route::get('/dashboard/usermanagement/create', [UserController::class, 'create'])->name('dashboard.usermanagement.create');
        Route::post('/dashboard/usermanagement/store', [UserController::class, 'store'])->name('dashboard.usermanagement.store');
        Route::get('/dashboard/usermanagement/{user}/edit', [UserController::class, 'edit'])->name('dashboard.usermanagement.edit');
        Route::put('/dashboard/usermanagement/{user}', [UserController::class, 'update'])->name('dashboard.usermanagement.update');
        Route::delete('/dashboard/usermanagement/{user}', [UserController::class, 'destroy'])->name('dashboard.usermanagement.destroy');
    });

    Route::middleware(['role:admin,company'])->group(function () {
    });

    Route::middleware(['role:company'])->group(function () {
        Route::get('dashboard/applicant-management', [ApplicantController::class, 'index'])
            ->name('dashboard.applicant-management.index');
        Route::delete('dashboard/applicant-management/{id}', [ApplicantController::class, 'destroy'])
            ->name('dashboard.applicant-management.destroy');
        Route::post('dashboard/applicant-management/apply/{jobId}', [ApplicantController::class, 'apply'])
            ->name('dashboard.applicant-management.apply');
        Route::get('/dashboard/job-management', [PostController::class, 'index'])->name('dashboard.job-management');
        Route::get('/dashboard/job-management/create', [PostController::class, 'create'])->name('dashboard.job-management.create');
        Route::post('/dashboard/job-management/store', [PostController::class, 'store'])->name('dashboard.job-management.store');
        Route::get('/dashboard/job-management/{post}/edit', [PostController::class, 'edit'])->name('dashboard.job-management.edit');
        Route::put('/dashboard/job-management/{post}', [PostController::class, 'update'])->name('dashboard.job-management.update');
        Route::delete('/dashboard/job-management/{post}', [PostController::class, 'destroy'])->name('dashboard.job-management.destroy');



    });
});
require __DIR__ . '/auth.php';
