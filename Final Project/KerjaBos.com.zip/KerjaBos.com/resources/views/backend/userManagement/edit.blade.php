<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('User Management') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-dark dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <p class="mb-4 badge fw-bold bg-warning text-dark text-uppercase"
                        style="font-size:20px;font-weight:200;padding:10px; font-family: sans-serif">Edit
                        @if ($user->role == 'admin')
                            Admin
                        @elseif($user->role == 'user')
                            User
                        @else
                            Company
                        @endif
                    </p>

                    {{-- Form Edit User --}}
                    <form id="editForm" action="{{ route('dashboard.usermanagement.update', $user->id) }}"
                        enctype="multipart/form-data" method="POST">
                        @csrf
                        @method('PUT')

                        <div>
                            <x-input-label for="role" :value="__('Role')" />
                            <select id="role" name="role"
                                class="mt-1 block w-full bg-transparent text-light rounded-md">
                                <option class="text-dark" value="admin"
                                    {{ old('role', $user->role) === 'admin' ? 'selected' : '' }}>Admin</option>
                                <option class="text-dark" value="user"
                                    {{ old('role', $user->role) === 'user' ? 'selected' : '' }}>User</option>
                                <option class="text-dark" value="company"
                                    {{ old('role', $user->role) === 'company' ? 'selected' : '' }}>Company</option>
                            </select>
                            <x-input-error class="mt-2" :messages="$errors->get('role')" />
                        </div>

                        <div class="mt-4">
                            <x-input-label for="name" :value="__('Name')" />
                            <x-text-input id="name" name="name" type="text" class="mt-1 block w-full"
                                :value="old('name', $user->name)" required autofocus autocomplete="name" />
                            <x-input-error class="mt-2" :messages="$errors->get('name')" />
                        </div>

                        <div class="mt-4">
                            <x-input-label for="username" :value="__('Username')" />
                            <x-text-input id="username" name="username" type="text" class="mt-1 block w-full"
                                :value="old('username', $user->username)" required autofocus autocomplete="username" />
                            <x-input-error class="mt-2" :messages="$errors->get('username')" />
                        </div>

                        <div class="mt-4">
                            <x-input-label for="email" :value="__('Email')" />
                            <x-text-input id="email" name="email" type="email" class="mt-1 block w-full"
                                :value="old('email', $user->email)" required autocomplete="username" />
                            <x-input-error class="mt-2" :messages="$errors->get('email')" />
                        </div>

                        <div class="mt-4">
                            <x-input-label for="phone" :value="__('No.Phone')" />
                            <x-text-input id="phone" name="phone" type="text" class="mt-1 block w-full"
                                :value="old('phone', $user->phone)" required autocomplete="phone" />
                            <x-input-error class="mt-2" :messages="$errors->get('phone')" />
                        </div>

                        @if ($user->role == 'user')
                            <div class="mt-4">
                                <x-input-label for="age" :value="__('Age')" />

                                <x-text-input id="age" name="age" type="text" class="mt-1 block w-full"
                                    :value="old('age', $user->age)" required autocomplete="age" />
                                <x-input-error class="mt-2" :messages="$errors->get('age')" />

                            </div>

                            <div class="mt-4">
                                <x-input-label for="gender" :value="__('Gender')" />
                                <select id="gender" name="gender"
                                    class="mt-1 block w-full bg-transparent text-light rounded-md">
                                    <option class="text-dark" value="female"
                                        {{ old('gender', $user->gender) === 'female' ? 'selected' : '' }}>Female
                                    </option>
                                    <option class="text-dark" value="male"
                                        {{ old('gender', $user->gender) === 'male' ? 'selected' : '' }}>Male</option>
                                </select>
                                <x-input-error class="mt-2" :messages="$errors->get('gender')" />
                            </div>
                        @endif

                        <button type="button" class="btn btn-success mt-4" onclick="confirmUpdate()">Update</button>
                        <a href="{{ route('dashboard.usermanagement.index') }}"
                            class="btn btn-secondary mt-4">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmUpdate() {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to update the user.',
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, update it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('editForm').submit();
                }
            });
        }
    </script>
</x-app-layout>
