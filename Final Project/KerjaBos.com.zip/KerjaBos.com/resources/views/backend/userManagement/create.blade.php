<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('User Management') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-dark dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <p class="mb-4 badge fw-bold bg-warning text-dark text-uppercase"
                        style="font-size:20px;font-weight:200;padding:10px; font-family: sans-serif">CREATE USER
                    </p>
                    {{-- Form Create User --}}
                    <form id="createForm" action="{{ route('dashboard.usermanagement.store') }}" method="POST"
                        enctype="multipart/form-data">
                        @csrf

                        <div>
                            <x-input-label for="role" :value="__('Role')" />
                            <select id="role" name="role"
                                class="mt-1 block w-full bg-transparent text-light rounded-md"
                                onchange="toggleFields()">
                                <option class="text-dark" value="admin"
                                    {{ old('role') === 'admin' ? 'selected' : '' }}>Admin</option>
                                <option class="text-dark" value="company"
                                    {{ old('role') === 'company' ? 'selected' : '' }}>Company
                                </option>
                                <option class="text-dark" value="user" {{ old('role') === 'user' ? 'selected' : '' }}>
                                    User</option>
                            </select>
                            <x-input-error class="mt-2" :messages="$errors->get('role')" />
                        </div>

                        <div class="mt-4">
                            <x-input-label for="name" :value="__('Name')" />
                            <x-text-input id="name" name="name" type="text" class="mt-1 block w-full"
                                :value="old('name')" required autofocus />
                            <x-input-error class="mt-2" :messages="$errors->get('name')" />
                        </div>


                        <div class="mt-4">
                            <x-input-label for="username" :value="__('Username')" />
                            <x-text-input id="username" name="username" type="text" class="mt-1 block w-full"
                                :value="old('username')" required />
                            <x-input-error class="mt-2" :messages="$errors->get('username')" />
                        </div>

                        <div class="mt-4">
                            <x-input-label for="email" :value="__('Email')" />
                            <x-text-input id="email" name="email" type="email" class="mt-1 block w-full"
                                :value="old('email')" required />
                            <x-input-error class="mt-2" :messages="$errors->get('email')" />
                        </div>

                        <div class="mt-4">
                            <x-input-label for="phone" :value="__('No.Phone')" />
                            <x-text-input id="phone" name="phone" type="text" class="mt-1 block w-full"
                                :value="old('phone')" />
                            <x-input-error class="mt-2" :messages="$errors->get('phone')" />
                        </div>

                        <div class="mt-4" id="ageField">
                            <x-input-label for="age" :value="__('Age')" />
                            <x-text-input id="age" name="age" type="text" class="mt-1 block w-full"
                                :value="old('age')" />
                            <x-input-error class="mt-2" :messages="$errors->get('age')" />
                        </div>

                        <div class="mt-4" id="genderField">
                            <x-input-label for="gender" :value="__('Gender')" />
                            <select id="gender" name="gender"
                                class="mt-1 block w-full bg-transparent text-light rounded-md">
                                <option class="text-dark" value=" " {{ old('gender') === ' ' ? 'selected' : '' }}>
                                </option>
                                <option class="text-dark" value="female"
                                    {{ old('gender') === 'female' ? 'selected' : '' }}>Female
                                </option>
                                <option class="text-dark" value="male"
                                    {{ old('gender') === 'male' ? 'selected' : '' }}>Male</option>
                            </select>
                            <x-input-error class="mt-2" :messages="$errors->get('gender')" />
                        </div>

                        <div class="mt-4" id="descriptionField">
                            <x-input-label for="description" :value="__('Description')" />
                            <div class="bg-white rounded-md p-2 text-dark">
                                <input id="description" type="hidden" name="description">
                                <textarea id="editor-description" name="description" rows="5"
                                    style="resize: vertical; width: 100%; min-height: 100px;"></textarea>
                                <x-input-error class="mt-2" :messages="$errors->get('description')" />
                            </div>
                        </div>

                        <div class="mt-4" id="skillsField">
                            <x-input-label for="skills" :value="__('Skills')" />
                            <div class="bg-white rounded-md p-2 text-dark">
                                <input id="skills" type="hidden" name="skills">
                                <textarea id="editor-skills" name="skills" rows="5" style="resize: vertical; width: 100%; min-height: 100px;"></textarea>
                                <x-input-error class="mt-2" :messages="$errors->get('skills')" />
                            </div>
                        </div>

                        <div class="mt-4" id="logoField">
                            <x-input-label for="logo" :value="__('Logo')" />
                            <input type="file" id="logo" name="logo" class="mt-1 block w-full"
                                accept="image/*" onchange="previewLogo(this)">
                            <div id="logoPreview" class="mt-2"></div>
                            <x-input-error class="mt-2" :messages="$errors->get('logo')" />
                        </div>

                        <div class="mt-4">
                            <x-password-input id="password" name="password" label="Password" />
                            <x-input-error class="mt-2" :messages="$errors->get('password')" />
                        </div>

                        <div class="mt-4">
                            <x-password-input id="password_confirmation" name="password_confirmation"
                                label="Confirm Password" />
                            <x-input-error class="mt-2" :messages="$errors->get('password_confirmation')" />
                        </div>

                        <button type="button" class="btn btn-success mt-4" onclick="confirmCreate()">Create</button>
                        <a href="{{ route('dashboard.usermanagement.index') }}"
                            class="btn btn-secondary mt-4">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        function confirmCreate() {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to create a new user.',
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, create it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('createForm').submit();
                }
            });
        }

        function toggleFields() {
            var roleSelect = document.getElementById('role');
            var logoField = document.getElementById('logoField');
            var skillsField = document.getElementById('skillsField');
            var ageField = document.getElementById('ageField');
            var genderField = document.getElementById('genderField');
            var descriptionField = document.getElementById('descriptionField');

            if (roleSelect.value === 'admin') {
                logoField.style.display = 'none';
                skillsField.style.display = 'none';
                descriptionField.style.display = 'none';
                ageField.style.display = 'none';
                genderField.style.display = 'none';

            } else if (roleSelect.value === 'company') {
                logoField.style.display = 'block';
                skillsField.style.display = 'none';
                descriptionField.style.display = 'block';
                ageField.style.display = 'none';
                genderField.style.display = 'none';
            } else {
                logoField.style.display = 'none';
                skillsField.style.display = 'block';
                descriptionField.style.display = 'block';
                ageField.style.display = 'block';
                genderField.style.display = 'block';
            }
        }


        function previewLogo(input) {
            var logoPreview = document.getElementById('logoPreview');
            var file = input.files[0];

            if (file) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    logoPreview.innerHTML = '<img src="' + e.target.result +
                        '" alt="Logo Preview" class="max-w-full h-auto">';
                    logoPreview.style.display = 'block';
                };

                reader.readAsDataURL(file);
            } else {
                logoPreview.innerHTML = '';
                logoPreview.style.display = 'none';
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            toggleFields();
        });
    </script>
</x-app-layout>
