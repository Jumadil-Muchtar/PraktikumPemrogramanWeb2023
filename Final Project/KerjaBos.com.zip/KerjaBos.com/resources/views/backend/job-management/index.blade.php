@php
    use Illuminate\Support\Facades\Auth;
    $currentAuthUser = Auth::user();
@endphp

<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('User Management') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-dark dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <p class="mb-4 badge fw-bold bg-warning text-dark text-uppercase"
                        style="font-size:20px;font-weight:200;padding:10px; font-family: sans-serif">
                        BY {{ $currentAuthUser->name }}
                    </p>
                    <a href="{{ route('dashboard.job-management.create') }}">
                        <p class="mb-4 badge fw-bold bg-success text-dark text-uppercase"
                            style="font-size:20px;font-weight:200;padding:10px; font-family: sans-serif">create post +
                        </p>
                    </a>

                    <!-- Tabel User -->
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 table-bordered border"
                        style="width:100%">
                        <thead class="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Title
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Location
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Type
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Phone
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Salary
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Created At
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Active
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-dark divide-y divide-gray-200 dark:divide-gray-700">
                            @foreach ($posts as $post)
                                @if ($post->user_id === $currentAuthUser->id)
                                    <tr>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">{{ $post->title }}</td>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">{{ $post->location }}</td>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">{{ $post->type }}</td>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">{{ $post->phone }}</td>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">{{ $post->salary }}</td>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">{{ $post->created_at }}</td>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">
                                            @if ($post->active == 1)
                                                Active
                                            @else
                                                Inactive
                                            @endif
                                        </td>
                                        <td class="px-6 py-2 whitespace-nowrap text-center">
                                            <div class="btn-group" role="group" aria-label="Basic example">
                                                <a href="{{ route('dashboard.job-management.edit', $post->id) }}"
                                                    class="badge bg-warning me-1 text-uppercase">Edit</a>
                                                <button type="button" class="badge bg-danger ms-1 text-uppercase"
                                                    onclick="confirmDelete({{ $post->id }})">Delete</button>
                                                <form id="deleteForm-{{ $post->id }}"
                                                    action="{{ route('dashboard.job-management.destroy', $post->id) }}"
                                                    method="POST" style="display: none;">
                                                    @csrf
                                                    @method('DELETE')
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- SweetAlert Script -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        function confirmDelete(postId) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You won\'t be able to revert this!',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Submit the form when confirmed
                    document.getElementById('deleteForm-' + postId).submit();
                }
            });
        }

        // Display success message if it exists
        document.addEventListener('DOMContentLoaded', function() {
            var successMessage = '{{ session('success') }}';

            if (successMessage) {
                Swal.fire({
                    title: 'Success',
                    text: successMessage,
                    icon: 'success',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK'
                });
            }
        });
    </script>
</x-app-layout>
