<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Job-Post Management') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-dark dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <p class="mb-4" style="font-size:20px;font-weight:200;padding:10px">Create Post</p>

                    {{-- Form Create User --}}
                    <form action="{{ route('dashboard.job-management.store') }}" method="POST" id="createForm">
                        @csrf


                        {{-- Title --}}
                        <div class="mt-4">
                            <x-input-label for="title" :value="__('Title')" />
                            <x-text-input id="title" name="title" type="text" class="mt-1 block w-full"
                                :value="old('title')" required autofocus />
                            <x-input-error class="mt-2" :messages="$errors->get('title')" />
                        </div>

                        {{-- Description --}}
                        <div class="mt-4">
                            <x-input-label for="description" :value="__('Description')" />
                            <div class="bg-white rounded-md p-2 text-dark">
                                <input id="description" type="hidden" name="description">
                                <textarea id="editor-description" name="description" rows="5"
                                    style="resize: vertical; width: 100%; min-height: 100px;"></textarea>
                                <x-input-error class="mt-2" :messages="$errors->get('description')" />
                            </div>
                        </div>

                        {{-- Location --}}
                        <div class="mt-4">
                            <x-input-label for="location" :value="__('Location')" />
                            <x-text-input id="location" name="location" type="text" class="mt-1 block w-full"
                                required />
                            <x-input-error class="mt-2" :messages="$errors->get('location')" />
                        </div>

                        {{-- Type Job --}}
                        <div class="mt-4">
                            <x-input-label for="type" :value="__('Type Job')" />
                            <select id="type" name="type"
                                class="mt-1 block w-full bg-transparent text-light rounded-md">
                                <option value="Full Time" {{ old('type') === 'Full Time' ? 'selected' : '' }}>Full Time
                                </option>
                                <option value="Part Time" {{ old('type') === 'Part Time' ? 'selected' : '' }}>Part Time
                                </option>
                                <option value="Freelance" {{ old('type') === 'Freelance' ? 'selected' : '' }}>Freelancer
                                </option>
                                <option value="Negotiable" {{ old('type') === 'Negotiable' ? 'selected' : '' }}>
                                    Negotiable</option>
                            </select>
                            <x-input-error class="mt-2" :messages="$errors->get('type')" />
                        </div>

                        {{-- Phone --}}
                        <div class="mt-4">
                            <x-input-label for="phone" :value="__('No.Phone')" />
                            <x-text-input id="phone" name="phone" type="text" class="mt-1 block w-full"
                                required />
                            <x-input-error class="mt-2" :messages="$errors->get('phone')" />
                        </div>

                        {{-- Salary --}}
                        <div class="mt-4">
                            <x-input-label for="salary" :value="__('Salary')" />
                            <x-text-input id="salary" name="salary" type="text" class="mt-1 block w-full"
                                required />
                            <x-input-error class="mt-2" :messages="$errors->get('salary')" />
                        </div>

                        {{-- Active Field Hidden --}}
                        <div class="mt-4">
                            <x-input-label for="active" :value="__('Active')" />
                            <select id="active" name="active"
                                class="mt-1 block w-full bg-transparent text-light rounded-md">
                                <option value="1" @if (old('active', $post->active ?? true)) selected @endif>Active</option>
                                <option value="0" @unless (old('active', $post->active ?? true)) selected @endunless>Inactive
                                </option>
                            </select>
                            <x-input-error class="mt-2" :messages="$errors->get('active')" />
                        </div>


                        <button type="button" class="btn btn-success mt-4" onclick="confirmCreate()">Create</button>
                        <a href="{{ route('dashboard.job-management') }}" class="btn btn-secondary mt-4">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- SweetAlert Script -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        function confirmCreate() {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to create a new post.',
                icon: 'info',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, create it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('createForm').submit();
                }
            });
        }

        // Tangkap pesan flash dari Laravel
        var successMessage = '{{ session('success') }}';

        // Jika ada pesan sukses, tampilkan SweetAlert
        if (successMessage) {
            Swal.fire({
                title: 'Success',
                text: successMessage,
                icon: 'success',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
            });
        }
    </script>
</x-app-layout>
