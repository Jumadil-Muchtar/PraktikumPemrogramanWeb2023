@php
    use Illuminate\Support\Facades\Auth;
    $currentAuthUser = Auth::user(); //
@endphp

<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Applicant Management') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-dark dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <p class="mb-4 badge fw-bold bg-warning text-dark text-uppercase"
                        style="font-size:20px;font-weight:200;padding:10px; font-family: sans-serif">BY
                        {{ $currentAuthUser->name }}
                    </p>


                    <!-- Tabel Applicant -->
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 table-bordered border"
                        style="width:100%">
                        <thead class="bg-gray-50 dark:bg-gray-700">
                            <tr>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Applicant's Name
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Email
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Skills
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Message
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Title Job
                                </th>
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody class="bg-dark divide-y divide-gray-200 dark:divide-gray-700">
                            @foreach ($applicants as $apply)
                                <tr>
                                    <td class="px-6 py-2 whitespace-nowrap text-center">
                                        {{ optional($apply->user)->name }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap text-center">
                                        {{ optional($apply->user)->email }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap text-center">{!! optional($apply->user)->skills !!}</td>
                                    <td class="px-6 py-2 whitespace-nowrap text-center">{{ $apply->message }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap text-center">{{ $apply->post->title }}</td>
                                    <td class="px-6 py-2 whitespace-nowrap text-center">
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <button type="button" class="badge bg-danger ms-1 text-uppercase"
                                                onclick="confirmDelete('{{ $apply->id }}')">Delete</button>

                                            <form id="deleteForm-{{ $apply->id }}"
                                                action="{{ route('dashboard.applicant-management.destroy', $apply->id) }}"
                                                method="POST" style="display: none;">
                                                @csrf
                                                @method('DELETE')
                                            </form>


                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- SweetAlert Script -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tangkap pesan flash dari Laravel
            var successMessage = '{{ session('success') }}';

            // Jika ada pesan sukses, tampilkan SweetAlert
            if (successMessage) {
                Swal.fire({
                    title: 'success',
                    text: successMessage,
                    icon: 'success',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK'
                });
            }
        });

        function confirmDelete(userId) {
            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to delete the applicant?.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Submit the form when confirmed
                    document.getElementById('deleteForm-' + userId).submit();
                }
            });
        }
    </script>
</x-app-layout>
