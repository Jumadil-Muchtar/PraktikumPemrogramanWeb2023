@php
    use Illuminate\Support\Str;
@endphp
<x-app-layout>
    <div class="py-12 text-light mt-3">
        <div class="jumbotron jumbotron-fluid">
            <div class="container"
                style="background-clip: text; color: transparent; background-image: linear-gradient(to right, #FFE4C4, #ffffff);">
                <h1 class="display-4 text-uppercase">KerjaBos.com</h1>
                <p class="lead">Platform pencarian pekerjaan yang didedikasikan untuk membantu para pencari kerja
                    menemukan peluang karir terbaik. Dengan fokus pada pengalaman pengguna yang intuitif dan berbagai
                    fitur unggulan, KerjaBos.com menjadi mitra ideal bagi mereka yang ingin mencapai karir yang sukses.
                </p>
            </div>
        </div>
    </div>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg" style="height: 100%; background-color:bisque">
                <div class="container-fluid p-5" style="width: 60%" data-aos="zoom-out-up">
                    <form class="d-flex" action="{{ route('search.results') }}" method="GET" role="search">
                        <input class="form-control me-2 rounded-md" type="search" placeholder="Search" name="search"
                            aria-label="Search">
                        <button class="btn btn-outline-success" type="submit">Search</button>
                    </form>
                </div>
                <div class="row d-flex">
                    @forelse ($allJobsPosts as $post)
                        <div class="col-md-4 pb-5 pt-3">
                            <a href="{{ route('job.detail', $post->slug) }}">
                                <div class="card mx-auto" style="width: 18rem;" data-aos="zoom-out-up">
                                    <div class="card-body bg-body-tertiary rounded-lg">
                                        <h5 class="card-title" style="font-weight: 800">
                                            {{ Str::limit($post->title, $limit = 30, $end = '...') }}
                                        </h5>
                                        <h6 class="card-subtitle mb-2 text-body-secondary d-flex gap-1"
                                            style="font-size: 13px">
                                            {{ optional($post->user)->name }}
                                            <img src="/img/verified.png" alt="">
                                        </h6>
                                        <hr class="p-1">
                                        <div class="d-flex gap-3 mb-2">
                                            <img src="/img/briefcase.png" alt="">
                                            <p class="card-text mt-1" style="font-size: 13px">
                                                {{ $post->type }}
                                            </p>
                                        </div>
                                        <div class="d-flex gap-3 mb-2">
                                            <img src="/img/location.png" alt="">
                                            <p class="card-text mt-1" style="font-size: 13px">{{ $post->location }}</p>
                                        </div>
                                        <div class="d-flex gap-3 mb-2">
                                            <img src="/img/salary.png" alt="">
                                            <p class="card-text mt-1" style="font-size: 13px">{{ $post->salary }}</p>
                                        </div>
                                        <a href="{{ route('job.detail', $post->slug) }}"
                                            class="badge bg-warning px-3 py-2">
                                            Details
                                        </a>
                                    </div>
                                </div>
                            </a>

                        </div>
                        @if ($loop->iteration % 3 == 0)
                </div>
                <div class="row d-flex">
                    @endif

                @empty
                    <div class="col-md-12 text-center py-5">
                        <p>No results found.</p>
                    </div>
                    @endforelse
                </div>
                <button id="scrollToTopBtn" class="btn btn-primary btn-lg rounded-circle" onclick="scrollToTop()"
                    title="Go to top">&#9650;</button>
            </div>
            <div class="mt-4">

            </div>
        </div>
    </div>


    <script>
        // Fungsi untuk mengarahkan halaman ke atas
        function scrollToTop() {
            document.body.scrollTop = 0; // Untuk Safari
            document.documentElement.scrollTop = 0; // Untuk Chrome, Firefox, IE, dan Opera
        }

        // Munculkan atau sembunyikan tombol mengambang berdasarkan posisi scroll
        window.addEventListener('scroll', function() {
            var scrollToTopBtn = document.getElementById("scrollToTopBtn");

            if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
                scrollToTopBtn.style.display = "block";
                scrollToTopBtn.style.position = "fixed";
                scrollToTopBtn.style.bottom = "20px";
                scrollToTopBtn.style.right = "20px";
                scrollToTopBtn.style.zIndex = "999";
            } else {
                scrollToTopBtn.style.display = "none";
            }
        });
    </script>

</x-app-layout>
