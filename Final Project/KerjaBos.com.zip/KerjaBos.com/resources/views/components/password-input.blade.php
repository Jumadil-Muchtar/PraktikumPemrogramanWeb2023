@props(['id', 'name', 'label'])

<div {{ $attributes }}>
    <label for="{{ $id }}" class="block text-sm font-medium text-light">{{ $label }}</label>
    <input type="password" name="{{ $name }}" id="{{ $id }}" autocomplete="new-password"
        {{ $attributes->merge(['class' => 'mt-1 p-2 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 bg-transparent']) }}>
</div>
