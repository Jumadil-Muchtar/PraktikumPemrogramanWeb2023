<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden shadow-sm sm:rounded-lg" style="height: 100%; background-color: bisque;">

                @if (empty($post))
                    <div class="row d-flex">
                        <div class="col-md-4 text-center p-5 mx-auto">
                            <p>No results found.</p>
                        </div>
                    </div>
                @else
                    <div class="row d-flex" data-aos="zoom-out-up">
                        <div class="col-md-10 py-3 ms-4 mt-2">
                            <h1 class="text-uppercase fw-bold" style="font-size: 20px">
                                {{ $post->title }}
                            </h1>
                            <div class="d-flex align-items-center mt-2">
                                <div class="me-3">
                                    <img src="{{ asset($post->user->logo) }}" alt="Photo"
                                        style="max-width: 50px; border-radius: 50%;">
                                </div>
                                <h1 class="font-bold text-dark text-uppercase d-flex" style="font-size: 15px; gap: 5px">
                                    {{ $post->user->name }}
                                    <img src="/img/verified.png" alt="">
                                </h1>
                            </div>

                            <div class="p-2 mt-4">
                                <p>
                                    {!! $post->description !!}
                                </p>
                            </div>
                            <button class="btn btn-primary mt-4" data-toggle="modal"
                                data-target="#applyModal">Apply</button>
                        </div>
                    </div>
                    <div class="mt-2">
                        <!-- Modal -->
                        <div class="modal fade" id="applyModal" tabindex="-1" role="dialog"
                            aria-labelledby="applyModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="applyModalLabel">Apply Form</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body bg-dark text-white">
                                        <!-- Formulir yang akan muncul di dalam modal -->
                                        <form action="{{ route('apply.post') }}" method="POST"
                                            enctype="multipart/form-data">
                                            @csrf
                                            <input type="hidden" name="post_id" value="{{ $post->id }}">
                                            <div class="mb-3">
                                                <label for="name" class="form-label">Name</label>
                                                <input type="text" value="{{ auth()->user()->name }}" id="name"
                                                    name="name" class="form-control rounded-md" required>
                                            </div>

                                            <div class="mb-3">
                                                <x-input-label for="skills" :value="__('Skills')" />
                                                <div class="bg-white rounded-md p-2 text-dark">
                                                    <input id="skills" type="hidden" name="skills"
                                                        value="{{ auth()->user()->skills }}">
                                                    <textarea id="editor-skills" name="skills" rows="5" style="resize: vertical; width: 100%; min-height: 100px;">{{ auth()->user()->skills }}</textarea>
                                                    <x-input-error class="mt-2" :messages="$errors->get('skills')" />
                                                </div>
                                            </div>

                                            <div class="mb-3">
                                                <label for="email" class="form-label">Email</label>
                                                <input type="email" value="{{ auth()->user()->email }}" id="email"
                                                    name="email" class="form-control rounded-md" required>
                                            </div>


                                            <div class="mb-3">
                                                <label for="message" class="form-label">Message</label>
                                                <textarea id="message" name="message" class="form-control rounded-md" required></textarea>
                                            </div>

                                            <div class="mb-3 mt-2">
                                                <button type="submit"
                                                    class="btn btn-success text-light">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif

            </div>
        </div>
    </div>

    @if (session('success'))
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '{{ session('success') }}',
            });
        </script>
    @elseif(session('error'))
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '{{ session('error') }}',
            });
        </script>
    @endif

</x-app-layout>
