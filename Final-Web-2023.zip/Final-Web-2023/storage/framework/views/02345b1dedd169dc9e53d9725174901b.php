<?php echo $__env->make('partials/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

<style>
    .create{
        margin-top: 100px;
    }
</style>

<div class="container create">
    <form action="<?php echo e(route('seller.create')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>


        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row mb-3">
            <label for="nama" class="col-md-4 col-form-label text-md-end">Nama Produk</label>
   
            <div class="col-md-4">
               <input id="nama" type="text" class="form-control" name="nama">
            </div>
        </div>

        <div class="row mb-3">
            <label for="deskripsi" class="col-md-4 col-form-label text-md-end">Deskripsi Produk</label>
   
            <div class="col-md-4">
               <input id="deskripsi" type="text" class="form-control" name="deskripsi">
            </div>
        </div>

        <div class="row mb-3">
            <label for="harga" class="col-md-4 col-form-label text-md-end">Harga Produk</label>
   
            <div class="col-md-4">
               <input id="harga" type="text" class="form-control" name="harga">
            </div>
        </div>

        <div class="row mb-3">
            <label for="stok" class="col-md-4 col-form-label text-md-end">Stok Produk</label>
   
            <div class="col-md-4">
               <input id="stok" type="text" class="form-control" name="stok">
            </div>
        </div>

        <div class="row mb-3">
            <label for="kategori" class="col-md-4 col-form-label text-md-end">Kategori Produk</label>
   
            <div class="col-md-4">
               <input id="kategori" type="text" class="form-control" name="kategori">
            </div>
        </div>

        <div class="row mb-3">
            <input type="file" name="photo">
            <button type="submit">Upload</button>
        </div>
    </form>
      
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Finall Project\Final-Web-2023\resources\views/seller/create.blade.php ENDPATH**/ ?>