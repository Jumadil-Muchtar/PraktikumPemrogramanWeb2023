<?php echo $__env->make('partials/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
   .profile {
      margin-top: 100px;     
   }
   .pro {
      font-family: poppins;
      font-weight: 600;
      font-size: 28px;
      color: #019267;
      margin-bottom: 20px;
   }
   .form-control {
      margin-left: -50px;
   }
   .btn {
      color: #019267;
   }
</style>

<?php $__env->startSection('content'); ?>
<div class="container profile">
   <h2 class="pro">Profile Management</h2>
   <form class="" role="search" method="POST" action="<?php echo e(route('profile.update')); ?>">
      <?php $__currentLoopData = $buyer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row mb-3">
         <label for="name" class="col-md-4 col-form-label text-md-end">Nama</label>

         <div class="col-md-4">
            <input id="name" type="text" class="form-control" name="name" value="<?php echo e($data->name); ?>">
         </div>
      </div>

      <div class="row mb-3">
            <label for="address" class="col-md-4 col-form-label text-md-end">Alamat Pengiriman</label>

            <div class="col-md-4">
               <input id="address" type="text" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address" value="<?php echo e($data->address); ?>" required autocomplete="address">
            </div>                        
      </div>

      <div class="row mb-3">
         <label for="email" class="col-md-4 col-form-label text-md-end">Email</label>

         <div class="col-md-4">
            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($data->email); ?>" required autocomplete="email">
         </div>
      </div>

      <div class="row mb-3">
         <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>

         <div class="col-md-6">
            <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
         </div>
         </div>
         <button type="submit" class="btn btn-success btn-sm">Ubah</button>
      </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Finall Project\Final-Web-2023\resources\views/buyerDash.blade.php ENDPATH**/ ?>