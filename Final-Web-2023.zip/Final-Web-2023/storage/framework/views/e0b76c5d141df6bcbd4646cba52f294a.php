<?php echo $__env->make('partials/navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
   .btn-our {
   background-color: #019267;
   color: #fff;
   display: flex;
   justify-content: center;
   align-items: center;
   margin: 80px 0;
   padding: 10px 0;
   font-family: poppins;
   font-weight: 600;
   font-size: 24px;
   text-align: center;
   text-decoration: none;
   border-radius: 10px;
   }

   .card-title {
      font-family: poppins;
      font-weight: 500;
      font-size: 18px;
      color: black;
   }.card-title:hover {
      color: #019267;
   }

   .card-text {
      font-family: poppins;
      font-weight: 400;
      font-size: 14px;
   }

</style>

<?php $__env->startSection('content'); ?>
<div class="container">
   <p class="btn-our">Our Products</p>

   

   <div style="display: flex; flex-wrap: wrap; justify-content: center">
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="card" style="width: 250px; margin: 5px 5px; ">
            <img src="" class="card-img-top" alt="<?php echo e($product->nama); ?>">
            <div class="card-body">
               <a class="card-title" href="<?php echo e(route('products.show', $product->nama)); ?>"><?php echo e($product->nama); ?></a>
               
               <p class="card-text">Harga: Rp<?php echo e($product->harga); ?></p>
               
            </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </div>
 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Finall Project\Final-Web-2023\resources\views/product.blade.php ENDPATH**/ ?>