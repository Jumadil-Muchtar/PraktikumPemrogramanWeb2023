@extends('layouts/main')
@include('partials/navbar')

@section('content')

<div class="container">
   <h5>Keranjang Belanja</h5>
   
</div>


@endsection